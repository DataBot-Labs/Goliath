#include "DRV8825_7Axis.h"

DRV8825_7Axis::DRV8825_7Axis() {
    enabled = false;
}

void DRV8825_7Axis::begin(uint8_t enablePin, const uint8_t stepPins[7], const uint8_t dirPins[7]) {
    this->enablePin = enablePin;
    pinMode(enablePin, OUTPUT);
    
    for (int i = 0; i < 7; i++) {
        motors[i].stepPin = stepPins[i];
        motors[i].dirPin = dirPins[i];
        
        pinMode(stepPins[i], OUTPUT);
        pinMode(dirPins[i], OUTPUT);
        
        motors[i].currentPosition = 0;
        motors[i].targetPosition = 0;
        motors[i].currentSpeed = 0;
        motors[i].maxSpeed = 1000.0;  // Default max speed
        motors[i].acceleration = 1000.0;  // Default acceleration
        motors[i].lastStepTime = 0;
        motors[i].stepInterval = 0;
    }
    
    // Start the timer interrupt
    timer.begin([this] { this->timerISR(); }, 1000);  // 1 kHz default
}

void DRV8825_7Axis::moveTo(long positions[7]) {
    for (int i = 0; i < 7; i++) {
        motors[i].targetPosition = positions[i];
    }
}

void DRV8825_7Axis::moveBy(long displacements[7]) {
    for (int i = 0; i < 7; i++) {
        motors[i].targetPosition = motors[i].currentPosition + displacements[i];
    }
}

void DRV8825_7Axis::setMaxSpeed(float speeds[7]) {
    for (int i = 0; i < 7; i++) {
        motors[i].maxSpeed = speeds[i];
    }
}

void DRV8825_7Axis::setAcceleration(float accelerations[7]) {
    for (int i = 0; i < 7; i++) {
        motors[i].acceleration = accelerations[i];
    }
}

void DRV8825_7Axis::enableMotors() {
    digitalWrite(enablePin, LOW);
    enabled = true;
}

void DRV8825_7Axis::disableMotors() {
    digitalWrite(enablePin, HIGH);
    enabled = false;
}

void DRV8825_7Axis::stop() {
    for (int i = 0; i < 7; i++) {
        motors[i].targetPosition = motors[i].currentPosition;
        motors[i].currentSpeed = 0;
    }
}

bool DRV8825_7Axis::isRunning() {
    for (int i = 0; i < 7; i++) {
        if (motors[i].currentPosition != motors[i].targetPosition) {
            return true;
        }
    }
    return false;
}

void DRV8825_7Axis::setMicrosteps(uint8_t m0, uint8_t m1, uint8_t m2) {
    // You'll need to connect M0, M1, M2 pins from all DRV8825 to the same control pins
    // Or implement individual control if needed
    pinMode(m0, OUTPUT);
    pinMode(m1, OUTPUT);
    pinMode(m2, OUTPUT);
    
    // Set the microstep resolution (example for 1/16th microstepping)
    digitalWrite(m0, HIGH);
    digitalWrite(m1, HIGH);
    digitalWrite(m2, HIGH);
}

void DRV8825_7Axis::update() {
    // This would be called from the main loop to handle non-time-critical updates
}

void DRV8825_7Axis::timerISR() {
    static unsigned long lastTime = 0;
    unsigned long currentTime = micros();
    float dt = (currentTime - lastTime) / 1000000.0;  // Convert to seconds
    lastTime = currentTime;
    
    // Calculate new speeds for all motors
    for (int i = 0; i < 7; i++) {
        if (motors[i].currentPosition != motors[i].targetPosition) {
            // Determine direction
            int direction = (motors[i].targetPosition > motors[i].currentPosition) ? 1 : -1;
            
            // Calculate distance to target
            long distance = abs(motors[i].targetPosition - motors[i].currentPosition);
            
            // Calculate maximum possible speed at which we can still decelerate to stop
            float maxReachableSpeed = sqrt(2.0 * motors[i].acceleration * distance);
            float targetSpeed = min(motors[i].maxSpeed, maxReachableSpeed);
            
            // Accelerate or decelerate
            if (motors[i].currentSpeed < targetSpeed) {
                // Accelerate
                motors[i].currentSpeed += motors[i].acceleration * dt;
                if (motors[i].currentSpeed > targetSpeed) {
                    motors[i].currentSpeed = targetSpeed;
                }
            } else if (motors[i].currentSpeed > targetSpeed) {
                // Decelerate
                motors[i].currentSpeed -= motors[i].acceleration * dt;
                if (motors[i].currentSpeed < targetSpeed) {
                    motors[i].currentSpeed = targetSpeed;
                }
            }
            
            // Calculate step interval
            if (motors[i].currentSpeed != 0) {
                motors[i].stepInterval = 1000000.0 / abs(motors[i].currentSpeed);
                
                // Step the motor if it's time
                if (currentTime - motors[i].lastStepTime >= motors[i].stepInterval) {
                    stepMotor(i);
                    motors[i].currentPosition += direction;
                    motors[i].lastStepTime = currentTime;
                }
            }
        } else {
            motors[i].currentSpeed = 0;
        }
    }
}

void DRV8825_7Axis::stepMotor(uint8_t motorIndex) {
    // Set direction
    digitalWrite(motors[motorIndex].dirPin, (motors[motorIndex].targetPosition > motors[motorIndex].currentPosition) ? HIGH : LOW);
    
    // Pulse step pin
    digitalWrite(motors[motorIndex].stepPin, HIGH);
    delayMicroseconds(2);  // Minimum pulse width for DRV8825 is 1.9μs
    digitalWrite(motors[motorIndex].stepPin, LOW);
}