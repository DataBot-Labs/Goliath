#ifndef DRV8825_7Axis_h
#define DRV8825_7Axis_h

#include <Arduino.h>
#include <IntervalTimer.h>

class DRV8825_7Axis {
public:
    // Constructor
    DRV8825_7Axis();

    // Initialize the library with pin configurations
    void begin(uint8_t enablePin, const uint8_t stepPins[7], const uint8_t dirPins[7]);

    // Movement control
    void moveTo(long positions[7]);  // Absolute position
    void moveBy(long displacements[7]);  // Relative movement

    // Speed and acceleration configuration
    void setMaxSpeed(float speeds[7]);  // Steps per second
    void setAcceleration(float accelerations[7]);  // Steps per second^2

    // Motor control
    void enableMotors();
    void disableMotors();

    // Runtime control
    void stop();  // Emergency stop
    bool isRunning();  // Check if any motor is moving

    // Microstepping configuration
    void setMicrosteps(uint8_t m0, uint8_t m1, uint8_t m2);

    // Update function to be called regularly
    void update();

private:
    // Motor data structure
    struct Motor {
        uint8_t stepPin;
        uint8_t dirPin;
        long currentPosition;
        long targetPosition;
        float currentSpeed;
        float maxSpeed;
        float acceleration;
        unsigned long lastStepTime;
        float stepInterval;
    };

    Motor motors[7];
    uint8_t enablePin;
    bool enabled;
    IntervalTimer timer;

    // Private methods
    void timerISR();
    void calculateSpeedProfile();
    void stepMotor(uint8_t motorIndex);
};

#endif